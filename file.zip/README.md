<html>
  <head> </head>
  <body>
    <h1>Banner Add'n Drop Chrome Extension</h1>
    <ol>
      <li>
        <a
          href="https://georgiancollege.sharepoint.com/sites/go/Pages/Banner.aspx?web=1"
          >Go to Banner</a
        >
      </li>
      <li>Login</li>
      <li>Registration</li>
      <li>Add/Drop/Withdraw From Courses</li>
      <li>Select Term</li>
      <li>Class Search</li>
      <li>Class Search(Leave all filter empty)</li>
    </ol>
    <h1>Source Code</h1>
    <p>
      <a
        href="https://github.com/angelocarlotto/chrome_extension_banner_add_drop_georgian_college"
      >
        Git Hub</a
      >
    </p>
    <h1>Developer</h1>
    <p>Angelo Carlotto</p>
    <h1>Disclame</h1>
    <p>
      This extension is a student(Angelo Carlotto) initiative to improve its own
      skills. The code is free to reproduce, just ask to mention the developer.
    </p>
  </body>
</html>
